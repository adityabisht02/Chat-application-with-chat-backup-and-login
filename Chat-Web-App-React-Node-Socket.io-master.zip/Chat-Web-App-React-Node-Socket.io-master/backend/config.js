module.exports = {
    'secret': 'secret'
}